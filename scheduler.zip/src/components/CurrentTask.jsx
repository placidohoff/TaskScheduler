const formatTime = (minutes) => {
  const hours = Math.floor(minutes / 60);
  const mins = minutes % 60;
  const period = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 || 12;
  return `${displayHours}:${mins.toString().padStart(2, '0')} ${period}`;
};

export default function CurrentTask({ task }) {
  if (!task) return null;

  const now = new Date();
  const currentMinutes = now.getHours() * 60 + now.getMinutes();
  const timeElapsed = currentMinutes - task.startTime;
  const progress = Math.min(Math.max((timeElapsed / (task.endTime - task.startTime)) * 100, 0), 100);

  return (
    <div className="alert alert-warning mb-4">
      <h2 className="h4">Current Task</h2>
      <div className="d-flex justify-content-between align-items-center">
        <div>
          <h3 className="h5">{task.taskName}</h3>
          <p className="mb-1">
            {formatTime(task.startTime)} - {formatTime(task.endTime)}
          </p>
          <p className="mb-0">Time Remaining: {task.endTime - currentMinutes} minutes</p>
        </div>
        <div style={{ width: '200px' }}>
          <div className="progress" style={{ height: '20px' }}>
            <div 
              className="progress-bar bg-success" 
              role="progressbar" 
              style={{ width: `${progress}%` }}
              aria-valuenow={progress}
              aria-valuemin="0"
              aria-valuemax="100"
            >
              {Math.round(progress)}%
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
