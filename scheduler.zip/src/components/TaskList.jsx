export default function TaskList({ tasks, setCurrentTask, updateDuration, updatePosition }) {
  return (
    <>
      {tasks.map((task) => (
        <div key={task.id} className="card mb-2">
          <div className="card-body d-flex justify-content-between align-items-center">
            <div className="d-flex gap-3 align-items-center">
              <div className="input-group" style={{ width: '100px' }}>
                <input
                  type="number"
                  value={task.slotPosition}
                  onChange={(e) => updatePosition(task.id, parseInt(e.target.value))}
                  className="form-control"
                  min="1"
                />
                <span className="input-group-text">#</span>
              </div>
              <h3 className="h5 mb-0">{task.taskName}</h3>
            </div>
            <div className="d-flex gap-2">
              <div className="input-group" style={{ width: '150px' }}>
                <input
                  type="number"
                  value={task.duration}
                  onChange={(e) => updateDuration(task.id, parseInt(e.target.value))}
                  className="form-control"
                />
                <span className="input-group-text">minutes</span>
              </div>
              <button
                onClick={() => setCurrentTask(task)}
                className="btn btn-primary"
              >
                Start Task
              </button>
            </div>
          </div>
        </div>
      ))}
    </>
  );
}
