import { useState, useEffect, useMemo } from 'react';
import TaskList from './components/TaskList';
import CurrentTask from './components/CurrentTask';

function App() {
  const [tasks, setTasks] = useState([]);
  const [currentTask, setCurrentTask] = useState(null);

  useEffect(() => {
    fetch('/tasks.json')
      .then(res => res.json())
      .then(data => setTasks(data.sort((a, b) => a.slotPosition - b.slotPosition)));
  }, []);

  const updateTaskDuration = (taskId, newDuration) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, duration: newDuration } : task
    ));
  };

  const timeToMinutes = (hours, minutes) => hours * 60 + minutes;
  
  const scheduledTasks = useMemo(() => {
    const WORK_DAY_START = timeToMinutes(8, 30); // 8:30 AM
    let currentTime = WORK_DAY_START;
  
    return tasks.sort((a, b) => a.slotPosition - b.slotPosition).map(task => {
      let startTime = currentTime;
      let endTime = startTime + task.duration;
      
      // Update the current time for the next task
      currentTime = endTime;
  
      return { ...task, startTime, endTime };
    });
  }, [tasks]);
  
  useEffect(() => {
    const updateCurrentTask = () => {
      const now = new Date();
      const currentMinutes = now.getHours() * 60 + now.getMinutes();
      
      // Find the currently active task based on the time
      const currentTask = scheduledTasks.find(task => 
        currentMinutes >= task.startTime && currentMinutes < task.endTime
      ) || null;
  
      setCurrentTask(currentTask);
    };
    
    updateCurrentTask(); // Initial check
    const interval = setInterval(updateCurrentTask, 60000);
    return () => clearInterval(interval);
  }, [scheduledTasks]);
  
  const updatePosition = (taskId, newPosition) => {
    setTasks(tasks.map(task => 
      task.id === taskId ? { ...task, slotPosition: newPosition } : task
    ).sort((a, b) => a.slotPosition - b.slotPosition));
  };

  // const LUNCH_START = timeToMinutes(12, 30);
  // const LUNCH_END = timeToMinutes(13, 30);

  return (
    <div className="container p-4">
      <h1 className="h2 mb-4">Daily Scheduler</h1>
      <CurrentTask task={currentTask} />
      
      <TaskList 
        tasks={tasks} 
        setCurrentTask={setCurrentTask}
        updateDuration={updateTaskDuration}
        updatePosition={updatePosition}
      />
    </div>
  );
}

export default App;
